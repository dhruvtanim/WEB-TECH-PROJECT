<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="hp.css">
	<title>Homepage</title>
</head>

<body>
	<header>
			<nav>
				<ul>
					<div class="middle-content">
						<ul>
							<li><a href="#">Home</a></li>
							<li><a href="#">Trending Courses</a></li>
							<li><a href="#">Our Goal</a></li>							
						</ul>
					</div>	
						
					<li><a href="Login.php">Login</a></li>		
				</ul>
			</nav>
		<hr>
	</header>

	<section class="Title-section">
		
    		    <h1>Welcome to ✔SKILLSHARE</h1>
    		    <span></span>
    		    <p>Learn->Upgrade->Be Employeed</p>
    		    
	  
	</section>

	
</body>

</html>		
